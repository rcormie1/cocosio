#define BOOST_TEST_MODULE AllTests
#include <boost/test/unit_test.hpp>

