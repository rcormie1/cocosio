#pragma once

#include <deque>
#include <fc/io/raw.hpp>

namespace fc {
   namespace raw {


    } // namespace raw

} // namespace fc
